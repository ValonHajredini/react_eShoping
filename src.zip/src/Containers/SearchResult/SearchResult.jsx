import React,  { Component } from 'react';
import './SearchResult.css';

class SearchResult extends Component {

    render() {
        return (
            <div className="container">
                <h3>SearchResult page</h3>
            </div>
        )
    }
}
export default SearchResult;
