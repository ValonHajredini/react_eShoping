import React,  { Component } from 'react';
import './ProductPage.css';

class ProductPage extends Component {

    render() {
        return (
            <div className="container">
                <h3>ProductPage page</h3>
            </div>
        )
    }
}
export default ProductPage;
