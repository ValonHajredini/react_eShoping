import React,  { Component } from 'react';
import './LoginRegister.css';

class LoginRegister extends Component {

    render() {
        return (
            <div className="container">
                <h3>Login or register</h3>
            </div>
        )
    }
}
export default LoginRegister;
