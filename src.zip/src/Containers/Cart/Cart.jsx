import React,  { Component } from 'react';
import './Cart.css';

class Cart extends Component {

    render() {
        return (
            <div className="container">
                <h3>Cart page</h3>
            </div>
        )
    }
}
export default Cart;
