import React,  { Component } from 'react';
import './Checkout.css';

class Checkout extends Component {

    render() {
        return (
            <div className="container">
                <h3>Checkout Page</h3>
            </div>
        )
    }
}
export default Checkout;
