import React, { Component } from 'react';
import './Account.css';
class Account extends Component{

    render() {
        return (
            <div className="container">
                <h3>Acount</h3>
            </div>
        )
    }
}
export default Account;