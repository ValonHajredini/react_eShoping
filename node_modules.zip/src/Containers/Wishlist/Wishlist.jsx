import React,  { Component } from 'react';
import './Wishlist.css';

class Wishlist extends Component {

    render() {
        return (
            <div className="container">
                <h3>Wishlist page</h3>
            </div>
        )
    }
}
export default Wishlist;
